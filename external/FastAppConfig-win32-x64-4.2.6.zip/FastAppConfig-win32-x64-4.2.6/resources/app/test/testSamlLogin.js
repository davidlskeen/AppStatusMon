var log4js 			= require('log4js');
var log 			= log4js.getLogger("testSamlLogin");
var assert    		= require("chai").assert;
var appConfigManager   	= require("../src/AppConfigManager.js");
var restManager   		= require("../src/RestManager.js");

// Test Comment 

describe("Test SAML Login", function() {
	it('Get Applications', function (done) {
//		restManager.getAppJson(function (err,data){
//			console.log(data);
//			done();
//		});
		done();
    });
});
