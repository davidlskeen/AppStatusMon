var async 	= require("async");
var log4js 	= require('log4js');
var log 	= log4js.getLogger("HealthCheckManager");
var xmldom 	= require('xmldom').DOMParser;
var restManager = require('./RestManager');

exports.getAppList = function(selectedApps,callback){
	callback(selectedApps);
}

function getHealthRuleViolations(appId,timeFrame,callback)
{
	restManager.getHealthRuleViolations(appId,timeFrame,function(err,hrXMLString){

		var hrViolationInfo = {criticalCount:0,warningCount:0};

		if (hrXMLString) {
			var hrXML = new xmldom().parseFromString(hrXMLString, 'application/xml');
			var violationNodes = hrXML.getElementsByTagName('policy-violation');	

			for (var i=0;i<violationNodes.length;i++) {

				var node = violationNodes[i];
				var incidentStatus = node.getElementsByTagName('incidentStatus')[0].firstChild.textContent;
				var severity = node.getElementsByTagName('severity')[0].firstChild.textContent;
				
				if (incidentStatus != "CANCELLED") {

					if (severity == "CRITICAL") {
						hrViolationInfo.criticalCount++;
					}
					else if (severity == "WARNING") {
						hrViolationInfo.warningCount++;
					}
				}
			}
		}
	
		callback(hrViolationInfo);

	});

}

function getCMRCount(xmlString)
{
	var enabledCount = 0;

	if (xmlString) {
		var cmrXML = new xmldom().parseFromString(xmlString, 'application/xml');
		var cmrNodes = cmrXML.getElementsByTagName('custom-match-point');	
		
		var disabledCount = 0;
		
		for (var j = 0; j < cmrNodes.length; j++) {

			var node = cmrNodes[j];
			var enabledNode = node.getElementsByTagName('enabled')[0];

			if (enabledNode.textContent == "true") {
				enabledCount+=1;
			}
			else {
				disabledCount+=1;
			}
		}
	}			
	return enabledCount;
}

function getCustomMatchRuleCount(selectedApp,callback) {

	restManager.getAppCustomMatchRules(selectedApp.id,'',function(err3,cmrList){

		var enabledCount = getCMRCount(cmrList);

		restManager.getTiersJson(selectedApp.id,function(err4,tierList){

			async.eachSeries(tierList,function(tier,callback2) {
				restManager.getAppCustomMatchRules(selectedApp.id,tier.name,function(err4,cmrList2){
					enabledCount += getCMRCount(cmrList2);	
					callback2();
				});
			}, function(err) {
			 	if(err){throw err;}
			 	callback(enabledCount);
			});
		});
	});
}

function getAlertingStats(appData,selectedApp,callback) {

	restManager.fetchHealthRules(selectedApp.id,function(error,rules){

		if (error) {
			callback(error,null);
		} else {
			var hrList = [];
			var hrXML= new xmldom().parseFromString(rules, 'application/xml');

			var hrNodes = hrXML.getElementsByTagName('health-rule');	
			appData.hrCount = hrNodes.length;

			restManager.fetchPolicies(selectedApp.id,function(error2,policies){

				if (error2) {
					callback(error2,null);
				} else {
					appData.policyCount = policies.length;

					restManager.fetchActions(selectedApp.id,function(error3,actions){

						if (error3) {
							callback(error3,null);
						} else {
							appData.actionCount = actions.length;
							callback(null,appData);
						}
					});
				}
			});
		}
	});
}


exports.checkHealth = function(selectedApp,timeFrame,callback) {

	var appData = {};
	appData.id = selectedApp.id;
	appData.name = selectedApp.name;
	appData.callCount = 0;
	appData.hrCount = 0;
	appData.actionCount = 0;
	appData.policyCount = 0;
	
	getHealthRuleViolations(selectedApp.id,timeFrame,function(hrViolationInfo) {

		appData.hrViolationInfo = hrViolationInfo;
	
		restManager.getAppCallsPerMinute(selectedApp.name,timeFrame,function(err1,cpm) {

			if (cpm.length > 0 && cpm[0].metricValues.length > 0) {
				appData.callCount = cpm[0].metricValues[0].sum;
			}

			restManager.getBTList(selectedApp.name,function(err2,btList) {

				appData.btCount = btList.length;

				getCustomMatchRuleCount(selectedApp,function(enabledCount) {
					appData.enabledCMRCount = enabledCount;

					getAlertingStats(appData,selectedApp,function(err3,appData) {
						callback(err3,appData);
					});
				});
			});
		});
	});	
}