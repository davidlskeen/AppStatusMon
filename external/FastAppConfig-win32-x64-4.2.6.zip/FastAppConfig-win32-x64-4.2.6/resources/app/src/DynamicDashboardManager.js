var log4js = require('log4js');
var log = log4js.getLogger("DynamicDashboardManager");
var restManager = require('./RestManager');
var configManager = require('./ConfigManager');
var dashsamples = require("../dashsamples.json");
var Q = require('q');
var jp = require('jsonpath');
var fs = require('fs');

var themeHelper = require("./ThemeHelper.js");

exports.deployDynamicHealthRules = function(sampleId,application,selectedTiers,selectedBTs,callback){
    
    var sample = exports.findSampleById(sampleId);
    var url = exports.getRelativePath()+sample.path+"/hr.xml";

    fs.readFile(url, 'utf8', function (err, data) {
        if (err) throw err;

        var allXML = "";

        if (sample.btSelection)
        {
            for (var i = 0; i < selectedBTs.length; i++) {
                var btData = selectedBTs[i];
                var btXML = data.replace(/{bt_name}/g, btData.name);
                btXML = btXML.replace(/{tier_name}/g, btData.tierName);
                allXML = allXML + btXML;
            }
        }

        allXML = "<health-rules>" + allXML + "</health-rules>";
        restManager.postHealthRules(application.id,allXML,true,function(err,response){
            callback(err,response);
        });
    });
}

exports.findSampleById = function(id){
    var samples = dashsamples.samples.filter(function(item) {
        return item.id == id;
    });
    return samples[0];
}

exports.getRelativePath = function(){
    if (configManager.isServerMode()){
        return './public';
    }else{
        return __dirname+'/../public';
    }
}

postDashboard = function(dashboardJSON,callback) {

    if (dashboardJSON)
    {
        restManager.postDashboard(dashboardJSON,function(err,response){
            callback(err,response);
        });
    }
    else
    {
        callback("The dashboard could not be generated.",null);
    }
}

exports.deployDynamicDashboard = function(sampleId,application,themeId,selectedTiers,selectedBTs,flows,callback){

    log.debug("Deploying Dynamic Dashboard : BaseDir :"+__dirname);

    var dashboardJSON;
    var sample = exports.findSampleById(sampleId);

    if (sampleId == 15) // Tier Detail
    {
        exports.generateTierDetailJSON(sample,application,themeId,selectedTiers,callback);
    }
    else if (sampleId == 16 || sampleId == 17) // BT List
    {
        exports.generateBTListJSON(sample,application,themeId,selectedBTs,callback);
    }
    else if (sampleId == 6) // Exec
    {   
        exports.generateExecutiveJSON(sample,application,themeId,flows,callback);
    }    
}

exports.generateTierDetailJSON = function(sample,application,themeId,selectedTiers,callback)
{
    var mainURL = exports.getRelativePath()+sample.path+"/MainSection.json";
    var repeatURL = exports.getRelativePath()+sample.path+"/RepeatSection.json";

    fs.readFile(mainURL, 'utf8', function (err,mainString) {
        if (err) throw err;

        fs.readFile(repeatURL, 'utf8', function (err,repeatString) {
            if (err) throw err;

            var themeSettings = themeHelper.getThemeSettings(themeId);
            var widgetTemplates = [];
            var startY = 67;
            var rowHeight = 25;
            var rowGap = -1;
            var isAlternateRow = false;

            mainString = mainString.replace(/{app_name}/g, application.name);
            mainString = mainString.replace(/{dashboard_height}/g, startY + ((selectedTiers.length + 1) * rowHeight));
            mainString = mainString.replace(/{form_backgound}/g, themeSettings.formBackgroundColor);
            mainString = mainString.replace(/{text_color}/g, themeSettings.headerTextColor);
            mainString = mainString.replace(/{background_color}/g, themeSettings.headerBackgroundColor);

            for (var i = 0; i < selectedTiers.length; i++) {
                var tierData = selectedTiers[i];
                var tierSectionData = generateTierSection(application.name,tierData,startY,isAlternateRow,themeSettings,repeatString);
                widgetTemplates = widgetTemplates.concat(tierSectionData);
                isAlternateRow = !isAlternateRow;
                startY = startY + rowHeight + rowGap;
            }

            var mainJSON = JSON.parse(mainString);
            mainJSON.widgetTemplates = mainJSON.widgetTemplates.concat(widgetTemplates);
            postDashboard(mainJSON,callback);
        });
    });
}

generateTierSection = function(appName,tierData,startY,isAlternateRow,themeSettings,repeatString)
{
    repeatString = repeatString.replace(/{app_name}/g, appName);
    repeatString = repeatString.replace(/{tier_name}/g, tierData.name);
    repeatString = repeatString.replace(/{row_y}/g, startY);
    repeatString = repeatString.replace(/{text_color}/g, themeSettings.dataTextColor);

    if (isAlternateRow)
    {
        repeatString = repeatString.replace(/{background_color}/g, themeSettings.dataAltBackgroundColor);
    }
    else
    {
        repeatString = repeatString.replace(/{background_color}/g, themeSettings.dataBackgroundColor);
    }

    return JSON.parse(repeatString);
}

exports.generateBTListJSON = function(sample,application,themeId,selectedBTs,callback)
{
    var btListMainURL = exports.getRelativePath()+sample.path+"/MainSection.json";
    var btListRepeatURL = exports.getRelativePath()+sample.path+"/RepeatSection.json";

    fs.readFile(btListMainURL, 'utf8', function (err,mainString) {
        if (err) throw err;

        fs.readFile(btListRepeatURL, 'utf8', function (err,repeatString) {
            if (err) throw err;

            var themeSettings = themeHelper.getThemeSettings(themeId);
            var widgetTemplates = [];
            var startY = 20;
            var boxHeight = 196;
            var sectionGap = 10;

            mainString = mainString.replace(/{app_name}/g, application.name);
            mainString = mainString.replace(/{dashboard_height}/g, startY + (selectedBTs.length * (boxHeight + sectionGap)) + sectionGap);
            mainString = mainString.replace(/{form_backgound}/g, themeSettings.formBackgroundColor);

            for (var i = 0; i < selectedBTs.length; i++) {
                var btData = selectedBTs[i];
                var btSectionData = generateBTSection(application,btData,startY,themeSettings,repeatString);
                widgetTemplates = widgetTemplates.concat(btSectionData);
                startY = startY + boxHeight + sectionGap;
            }

            var mainJSON = JSON.parse(mainString);
            mainJSON.widgetTemplates = widgetTemplates;
            postDashboard(mainJSON,callback);
        });
    });
}

generateBTSection = function(application,btData,startY,themeSettings,repeatString)
{
    repeatString = repeatString.replace(/{app_name}/g, application.name);
    repeatString = repeatString.replace(/{tier_name}/g, btData.tierName);
    repeatString = repeatString.replace(/{bt_name}/g, btData.name);
    repeatString = repeatString.replace(/{bt_type}/g, btData.entryPointType);

    repeatString = repeatString.replace(/{controller_url}/g, configManager.getControllerURL());
    repeatString = repeatString.replace(/{app_id}/g, application.id);
    repeatString = repeatString.replace(/{bt_id}/g, btData.id);

    repeatString = repeatString.replace(/{box_y}/g, startY);
    repeatString = repeatString.replace(/{boxLabel_y}/g, startY + 9);
    repeatString = repeatString.replace(/{boxImage_url}/g, themeSettings.boxImageURL);

    repeatString = repeatString.replace(/{chart_y}/g, startY + 35);   
    repeatString = repeatString.replace(/{statusLight_y}/g, startY + 50);   
    repeatString = repeatString.replace(/{statusLight1_y}/g, startY + 44); 
    repeatString = repeatString.replace(/{statusLight2_y}/g, startY + 110); 
    repeatString = repeatString.replace(/{pieChart_y}/g, startY + 34)   

    repeatString = repeatString.replace(/{boxBackground_color}/g, themeSettings.boxBackgroundColor)   
    repeatString = repeatString.replace(/{text_color1}/g, themeSettings.headerTextColor)   
    repeatString = repeatString.replace(/{text_color2}/g, themeSettings.metricTextColor)   

    repeatString = repeatString.replace(/{box1_label1_y}/g, startY + 40);
    repeatString = repeatString.replace(/{box1_label2_y}/g, startY + 75);
    repeatString = repeatString.replace(/{box1_label3_y}/g, startY + 103);
    repeatString = repeatString.replace(/{box1_label4_y}/g, startY + 124);
    repeatString = repeatString.replace(/{box1_label5_y}/g, startY + 145);
    repeatString = repeatString.replace(/{box1_line_y}/g, startY + 97);

    repeatString = repeatString.replace(/{box4_label1_y}/g, startY + 50);
    repeatString = repeatString.replace(/{box4_label2_y}/g, startY + 72);
    repeatString = repeatString.replace(/{box4_label3_y}/g, startY + 94);
    repeatString = repeatString.replace(/{box4_label4_y}/g, startY + 116);
    repeatString = repeatString.replace(/{box4_label5_y}/g, startY + 138);

    repeatString = repeatString.replace(/{box4_img1_y}/g, startY + 50);
    repeatString = repeatString.replace(/{box4_img2_y}/g, startY + 72);
    repeatString = repeatString.replace(/{box4_img3_y}/g, startY + 94);
    repeatString = repeatString.replace(/{box4_img4_y}/g, startY + 116);
    repeatString = repeatString.replace(/{box4_img5_y}/g, startY + 138);

    return JSON.parse(repeatString);
}

exports.generateExecutiveJSON = function(sample,application,themeId,flows,callback)
{
    var mainURL = exports.getRelativePath()+sample.path+"/MainSection.json";
    var repeatURL = exports.getRelativePath()+sample.path+"/RepeatSection.json";
    var stepURL = exports.getRelativePath()+sample.path+"/StepSection.json";

    fs.readFile(mainURL, 'utf8', function (err,mainString) {
        if (err) throw err;

        fs.readFile(repeatURL, 'utf8', function (err,repeatString) {
            if (err) throw err;

            fs.readFile(stepURL, 'utf8', function (err,stepString) {
                if (err) throw err;

                var themeSettings = themeHelper.getThemeSettings(themeId);
                var widgetTemplates = [];
                var startY = 64;
                var rowHeight = 160;
                var stepWidth = 185;
                var sectionGap = 10;
                var maxSteps = 0;

                for (var i = 0; i < flows.length; i++) {
                    var flowData = flows[i];
                    var flowSectionData = generateFlowSection(application.name,flowData,startY,themeSettings,repeatString,i);
                    widgetTemplates = widgetTemplates.concat(flowSectionData);

                    var startX = 376;
                    maxSteps = Math.max(maxSteps,flowData.steps.length);

                    for (var j = 0; j < flowData.steps.length; j++) {
                        var isLastStep = (j == flowData.steps.length-1 ? true : false);
                        var stepData = flowData.steps[j];
                        var stepSectionData = generateStepSection(application.name,stepData,startY,startX,themeSettings,stepString,isLastStep);
                        widgetTemplates = widgetTemplates.concat(stepSectionData);
                        startX += stepWidth;
                    }

                    startY = startY + rowHeight + sectionGap;
                }


                mainString = mainString.replace(/{app_name}/g, application.name);
                mainString = mainString.replace(/{dashboard_height}/g, startY + (flows.length * (rowHeight + sectionGap)) + sectionGap);
                mainString = mainString.replace(/{dashboard_width}/g, (maxSteps * stepWidth) + startX);
                mainString = mainString.replace(/{form_backgound}/g, themeSettings.boxBackgroundColor);

                var mainJSON = JSON.parse(mainString);
                mainJSON.widgetTemplates = widgetTemplates;
                postDashboard(mainJSON,callback);
            });
        });
    });
}

generateFlowSection = function(applicationName,flowData,startY,themeSettings,repeatString,flowIndex)
{
    repeatString = repeatString.replace(/{image_y}/g, startY + 46);
    repeatString = repeatString.replace(/{label_y}/g, startY + 62);
    repeatString = repeatString.replace(/{nextImage_y}/g, startY + 56);
    repeatString = repeatString.replace(/{flow_name}/g, flowData.name);
    repeatString = repeatString.replace(/{form_backgound}/g, themeSettings.boxBackgroundColor);
    repeatString = repeatString.replace(/{text_color}/g, themeSettings.headerTextColor);
    repeatString = repeatString.replace(/{arrowColor_hex}/g, themeSettings.arrowColorHex);

    if (flowIndex == 0) {
        repeatString = repeatString.replace(/{icon_url}/g, themeSettings.houseSVG);
    }
    else if (flowIndex == 1) {
        repeatString = repeatString.replace(/{icon_url}/g, themeSettings.mobileSVG);
    }
    else if (flowIndex == 2) {
        repeatString = repeatString.replace(/{icon_url}/g, themeSettings.arrowCircleSVG);
    }    
    else {
        repeatString = repeatString.replace(/{icon_url}/g, themeSettings.monitorSVG);
    }

    repeatString = repeatString.replace(/{backgroundColor_hex}/g, themeSettings.formBackgroundColorHex);
    repeatString = repeatString.replace(/{iconColor_hex}/g, themeSettings.iconColorHex);
    
    return JSON.parse(repeatString);
}

generateStepSection = function(applicationName,stepData,startY,startX,themeSettings,stepString,isLastStep)
{
    stepString = stepString.replace(/{app_name}/g, applicationName);
    stepString = stepString.replace(/{hr_name}/g, stepData.hrName);
    stepString = stepString.replace(/{step_name}/g, stepData.name);
    stepString = stepString.replace(/{text_color}/g, themeSettings.headerTextColor);
    stepString = stepString.replace(/{form_backgound}/g, themeSettings.boxBackgroundColor);
    stepString = stepString.replace(/{backgroundColor_hex}/g, themeSettings.formBackgroundColorHex);
    stepString = stepString.replace(/{arrowColor_hex}/g, themeSettings.arrowColorHex);

    stepString = stepString.replace(/{stoplight_x}/g, startX);
    stepString = stepString.replace(/{stoplight_y}/g, startY+10);
    stepString = stepString.replace(/{stoplight_overlay_x}/g, startX+8);
    stepString = stepString.replace(/{stoplight_overlay_y}/g, startY+19);
    stepString = stepString.replace(/{label_x}/g, startX+15);
    stepString = stepString.replace(/{label_y}/g, startY+59);
    stepString = stepString.replace(/{arrow_image_x}/g, startX+144);
    stepString = stepString.replace(/{arrow_image_y}/g, startY+62);

    if (isLastStep) {
        stepString = stepString.replace(/{arrow_image_height}/g, 0);
        stepString = stepString.replace(/{circle_image_height}/g, 30);
    }
    else {
        stepString = stepString.replace(/{arrow_image_height}/g, 30);
        stepString = stepString.replace(/{circle_image_height}/g, 0);
    }
    
    return JSON.parse(stepString);
}
