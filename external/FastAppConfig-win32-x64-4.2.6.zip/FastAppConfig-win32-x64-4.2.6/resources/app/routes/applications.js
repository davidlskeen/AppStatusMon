var express = require('express');
var router = express.Router();

router.get('/', function(req, res) {

	req.appConfigManager.fetchApplications(function(err,results){

		if(err){
			res.status(500).send(err.statusMessage);
		}
		else {

			if (results) {

				if (results.apmApplications) {
					res.status(200).json(results.apmApplications);
				}
				else {
					res.status(200).json(results);
				}
			}
			else {
				res.status(500).json({"error":"not able to connect","details":results});
			}
		}
	})

});

module.exports = router;
