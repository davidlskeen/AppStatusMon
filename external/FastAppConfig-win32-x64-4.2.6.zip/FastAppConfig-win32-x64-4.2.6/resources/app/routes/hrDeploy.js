var express = require('express');
var router = express.Router();

router.post('/deployXML/', function(req, res) {

	var appID = req.body[0];
	var deployXML = req.body[1];
	
	req.restManager.postHealthRules(appID,deployXML,true,function(err,response){
		if (err) {
			res.status(500).send(err.body);
		} else {
			res.status(200).send("Sample Health Rule Copied Successfully");
		}
	});
});

router.get('/getHR/:applicationId/:hrName', function(req, res) {

	req.restManager.fetchHealthRule(req.params.applicationId,req.params.hrName,function(error,rule) {

		if (error) {
			res.status(500).send(error.body);
		} else {
			res.status(200).send(rule);
		}
	});
});

module.exports = router;
