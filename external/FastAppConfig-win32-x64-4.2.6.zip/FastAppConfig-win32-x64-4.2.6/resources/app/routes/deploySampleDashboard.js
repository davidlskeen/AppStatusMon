var express = require('express');
var router = express.Router();

router.post('/', function(req, res) {
	
	var sampleId = req.body[0];
	var application = req.body[1];
	var themeId = req.body[2];
	var btName;
	var btTierName;
	var btType;

	if (req.body.length > 4)
	{
		btName = req.body[3];
		btTierName = req.body[4];
		btType = req.body[5];
	}

	req.appConfigManager.deploySampleDashboard(sampleId,application,themeId,btName,btTierName,btType,function(err,results){
		if(err){
			res.status = 500;
			res.send(err.body);
		}else{
			res.status = 200;
			res.send("Sample Dashboard Deployed Successfully");
		}
	});
	
});

router.post('/dynamic/', function(req, res) {
	
	var sampleId = req.body[0];
	var application = req.body[1];
	var themeId = req.body[2];
	var selectedTiers = req.body[3];
	var selectedBTs = req.body[4];
	var flows = req.body[5];

	req.dynamicDashboardManager.deployDynamicDashboard(sampleId,application,themeId,selectedTiers,selectedBTs,flows,function(err,results){
		if(err){
			res.status = 500;
			res.send(err.body);
		}else{
			res.status = 200;
			res.send("Dashboard Deployed Successfully");
		}
	});
	
});

router.get('/bts/:applicationName', function(req, res) {

	req.restManager.getBTList(req.params.applicationName,function(err1,btNames){

		if(err1)
		{
			res.status(500).json(err1.body);
		}
		else
		{
			var btList = [];

			for (var i = 0; i < btNames.length; i++)
			{
				if (btNames[i].name != "_APPDYNAMICS_DEFAULT_TX_")
				{
					btNames[i].topN = false;
					btNames[i].createCMR = false;
					btNames[i].topCPM = false;
					btNames[i].topART = false;

					if (btNames[i].entryPointType == "SERVLET" || btNames[i].entryPointType == "ASP_DOTNET")
					{
						btNames[i].canCreateCMR = true;
					}
					else
					{
						btNames[i].canCreateCMR = false;
					}

					btList.push(btNames[i]);
				}
			}
			res.status(200).json(btList);
		}
	});
});

router.get('/hrs/:applicationId', function(req, res) {

	req.hrManager.getHRList(req.params.applicationId,function(error,rules){

		if(error)
		{
			res.status(500).json(error.body);
		}
		else
		{
			res.status(200).json(rules);
		}
	});
});

module.exports = router;
