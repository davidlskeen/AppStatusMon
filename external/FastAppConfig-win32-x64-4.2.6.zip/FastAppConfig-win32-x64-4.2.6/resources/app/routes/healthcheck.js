var express = require('express');
var router = express.Router();

router.post('/', function(req, res) {
	
	var selectedApp = req.body[0];
	var timeFrame = req.body[1];

	req.healthCheckManager.checkHealth(selectedApp,timeFrame,function(err,results){
		if(err){
			res.status(500).send(err.body);
		}else{
			res.status(200).json(results);
		}
	});
	
});

module.exports = router;
