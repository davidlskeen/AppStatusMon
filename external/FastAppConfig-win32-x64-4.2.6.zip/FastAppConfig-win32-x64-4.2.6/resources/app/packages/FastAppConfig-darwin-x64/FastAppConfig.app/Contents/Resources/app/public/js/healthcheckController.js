angular.module('HealthcheckApp', ['HealthcheckApp.controllers','HealthcheckApp.services','ngMaterial','ui.grid','ui.grid.exporter']);

angular.module('HealthcheckApp.controllers', ['HealthcheckApp.services']).
controller('HealthcheckController', function($scope,$window,healthcheckService,$mdDialog,$element) {

	healthcheckService.getApps($scope);
	$scope.showSpinner = false;

	$scope.applications = [];
	$scope.selectedApps = null;
	$scope.controllerData = [];

	$scope.appSearchTerm;
	$scope.healthcheckData = null;
	$scope.timeFrame = 1440;

	$scope.gridOptions = {
        enableSorting: true,
        columnDefs: [
          { displayName:'App Name', headerTooltip: 'App Name', field: 'name' },
          { displayName:'Total Calls', headerTooltip: 'Total Number of Calls', field: 'callCount', width: 100},
          { displayName:'BT Count', headerTooltip: 'Count of Business Transactions', field: 'btCount', width: 90},
          { displayName:'CMR Count', headerTooltip: 'Custom Match Rules', field: 'enabledCMRCount', width: 105},
          { displayName:'Critical Violations', headerTooltip: 'Health Rule Critical Violations', field: 'hrViolationInfo.criticalCount', width: 150},
          { displayName:'Warning Violations', headerTooltip: 'Health Rule Warning Violations', field: 'hrViolationInfo.warningCount', width: 160},
          { displayName:'HR Count', headerTooltip: 'Count of Health Rules', field: 'hrCount', width: 100},
          { displayName:'Actions', headerTooltip: 'Count of Actions', field: 'actionCount', width: 80},
          { displayName:'Policies', headerTooltip: 'Count of Policies', field: 'policyCount', width: 110}
        ],
        data : [  ],
        onRegisterApi: function(gridApi){ $scope.gridApi = gridApi;},
        exporterCsvFilename: "HealthCheckData.csv"
    };

	$scope.clearAppSearchTerm = function() {
		$scope.appSearchTerm = '';
	};

	$element.find('input').on('keydown', function(ev) {
		ev.stopPropagation();
	});

	$scope.hasSelectedApp=function() {

		if (!$scope.selectedApps || $scope.selectedApps.length == 0) {
			return false;
		}
		else {
			return true;
		}
	};

	$scope.hasGridData=function() {

		if ($scope.controllerData.length == 0) {
			return false;
		}
		else {
			return true;
		}
	};

	$scope.getSelectedAppsText = function() {
		if (!$scope.selectedApps || $scope.selectedApps.length == 0) 
		{
			return "Applications";
		} 
		else if ($scope.selectedApps.length == 1)
		{
			return "1 Application Selected";
		}
		else 
		{
			return $scope.selectedApps.length + " Applications Selected";
		}
	};

	$scope.checkControllerHealth = function(scope){
		$scope.selectedApps = $scope.applications;
		$scope.checkHealth();
	}	

	$scope.checkHealth = function(scope){
		$scope.showSpinner = true;
		$scope.spinnerText = "Finished " + $scope.controllerData.length + " out of " + $scope.selectedApps.length + " applications.";
		healthcheckService.checkHealth($scope);
		setTimeout(updateProgress, 200);
	}	

	$scope.exportData = function() {
		$scope.gridApi.exporter.csvExport('all', 'all');
	};

	function updateProgress() {

		if ($scope.controllerData.length < $scope.selectedApps.length) {
			$scope.spinnerText = "Finished " + $scope.controllerData.length + " out of " + $scope.selectedApps.length + " applications.";
			setTimeout(updateProgress, 200);
		}
		else {
			console.log($scope.controllerData);
			$scope.showSpinner = false;
			$scope.gridApi.core.refresh();
		}
	}

	$scope.showAlert = function(message) {
		$mdDialog.show(
			$mdDialog.alert()
			.parent(angular.element(document.querySelector('#popupContainer')))
			.clickOutsideToClose(true)
			.textContent(message)
			.ariaLabel('Alert Dialog Demo')
			.ok('OK')
		);
	};			
});

