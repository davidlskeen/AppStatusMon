angular.module('HealthcheckApp.services',[])
.factory('healthcheckService', function($http) {
	
	function Healthcheck(){
		this.data = null;
	}
	
	function _healthcheckService(){
		this.healthcheck = new Healthcheck();
	}
	
	_healthcheckService.prototype.getApps = function($scope) {
		$http.get('/applications.json').success(function(result) {
			$scope.applications = result;
		});	
	}

	_healthcheckService.prototype.checkHealth = function($scope) {

		$scope.controllerData = [];
		$scope.gridOptions.data = $scope.controllerData;

		for (var i = 0; i < $scope.selectedApps.length; i++) {
			
			var application = $scope.selectedApps[i];
			var request = [];
			request.push(application);
			request.push($scope.timeFrame);

			$http({
			    url: '/healthcheck',
			    method: "POST",
			    data: JSON.stringify(request),
			    headers: {'Content-Type': 'application/json'}
			}).success(function (data, status, headers, config) {
				$scope.controllerData.push(data);
			}).error(function (data, status, headers, config) {
				$scope.showSpinner = false;
				$scope.showAlert(data);
			});
		}
	}

	return new _healthcheckService();
});
