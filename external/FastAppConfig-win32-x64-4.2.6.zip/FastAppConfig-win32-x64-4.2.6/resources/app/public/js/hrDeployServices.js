angular.module('HRDeployApp.services',[])
.factory('hrDeployService', function($http) {
	
	function HRDeploy(){
		this.data = null;
	}
	
	function _hrDeployService(){
		this.hrDeploy = new HRDeploy();
	}
	
	_hrDeployService.prototype.getApps = function($scope) {
		$http.get('/applications.json').success(function(result) {
			$scope.applications = result;
		});	
	}

	_hrDeployService.prototype.deployHR = function($scope) {

		$scope.showSpinner = true;
		var postData = [];
		postData.push($scope.selectedApp.id);
		postData.push($scope.hrText);
				
		$http({
		    url: '/hrDeploy/deployXML',
		    method: "POST",
		    data: JSON.stringify(postData),
		    headers: {'Content-Type': 'application/json'}
	    }).success(function (result) {
	    	$scope.showSpinner = false;
			$scope.showAlert("Successfully deployed health rule.");
	    }).error(function(result) {
	    	$scope.showSpinner = false;
	    	$scope.showAlert(result);
	    });
	}

	_hrDeployService.prototype.getHR = function($scope,callback) {

		$scope.showSpinner = true;

		$http.get('/hrDeploy/getHR/'+$scope.selectedApp.id+'/'+$scope.selectedHR.name).success(function(result) {	
	        $scope.showSpinner = false;
	        callback(result);
		});
	}

	_hrDeployService.prototype.getHRList = function($scope,callback) {
	
		$scope.showSpinner = true;
	    $scope.hrList = [];

		$http.get('/deploySampleDashboard/hrs/'+$scope.selectedApp.id).success(function(result) {	
	        $scope.showSpinner = false;
	        callback(result);
		});
	}

	return new _hrDeployService();

});
