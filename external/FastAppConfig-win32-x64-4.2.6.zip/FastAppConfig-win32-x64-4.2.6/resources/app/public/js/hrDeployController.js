angular.module('HRDeployApp', ['HRDeployApp.controllers','HRDeployApp.services']);

angular.module('HRDeployApp').directive('onReadFile', function ($parse) {
    return {
        restrict: 'A',
        scope: false,
        link: function(scope, element, attrs) {
            element.bind('change', function(e) {
           
                var onFileReadFn = $parse(attrs.onReadFile);
                var reader = new FileReader();
                
                reader.onload = function() {
                    var fileContents = reader.result;
                    scope.$apply(function() {
                        onFileReadFn(scope, {
                            'contents' : fileContents
                        });
                    });
                };
                reader.readAsText(element[0].files[0]);
            });
        }
    };
})

angular.module('HRDeployApp.controllers', ['HRDeployApp.services','ngMaterial']).
controller('HRDeployController', function($scope,$window,hrDeployService,$mdDialog,$element) {

	hrDeployService.getApps($scope);
	$scope.showSpinner = false;

    $scope.displayFileContents = function(contents) {
        $scope.hrText = contents;
    };

	$scope.appSearchTerm;
	$scope.clearAppSearchTerm = function() {
		$scope.appSearchTerm = '';
	};

	$element.find('input').on('keydown', function(ev) {
		ev.stopPropagation();
	});

	$scope.applicationChanged = function(){
		hrDeployService.getHRList($scope, function(result) {	
			$scope.hrList = result;
			$scope.showSpinner = false;
		});
	};

	$scope.hasText = function(){

		if ($scope.hrText) {
			return true;
		}
		else {
			return false;
		}
	};

	$scope.deployHR = function() {
    	hrDeployService.deployHR($scope);
	};

	$scope.getHR = function() {
		hrDeployService.getHR($scope, function(result) {	
			console.log(result);
			$scope.hrText = result;
			$scope.showSpinner = false;
		});
	};

	$scope.showAlert = function(message) {
		$mdDialog.show(
			$mdDialog.alert()
			.parent(angular.element(document.querySelector('#popupContainer')))
			.clickOutsideToClose(true)
			.textContent(message)
			.ariaLabel('Alert Dialog Demo')
			.ok('OK')
		);
	};			
});

