angular.module('SampleApp', ['SampleApp.controllers']);

angular.module('SampleApp.controllers', ['ngMaterial']).
controller('SampleController', function($scope,$window,$element) {

	$scope.showSpinner = false;
	$scope.selectedThemeId;
	$scope.selectedTheme;
	$scope.themes;
	$scope.categories;
	$scope.selectedCategoryId;
	$scope.appSearchTerm;

	$scope.clearAppSearchTerm = function() {
		$scope.appSearchTerm = '';
	};
	$element.find('input').on('keydown', function(ev) {
		ev.stopPropagation();
	});

	$scope.themeChanged = function(){
		$scope.selectedTheme = findThemeById($scope.selectedThemeId);
	};

	$scope.filterFn = function(result)
	{
	    if (!$scope.selectedCategoryId)
	    {
	    	return true;
	    }
	    else if(result.categories && result.categories.indexOf($scope.selectedCategoryId) > -1)
	    {
	    	return true;
	    }
	    else
	    {
	    	return false;
	    }
	};

	$scope.init = function(value) {
		$scope.themes = value.themes;
		$scope.samples = value.samples;
		$scope.categories = value.categories;
	};

	$scope.initTheme = function(value) {
		$scope.selectedThemeId = value;
		if (!$scope.selectedThemeId)
		{
			$scope.selectedThemeId = 1;
		}
		$scope.selectedTheme = findThemeById($scope.selectedThemeId);
	};

	findThemeById = function(id){
		var themes = $scope.themes.filter(function(item) {
		    return item.id == id;
		});
		return themes[0];
	}

});

