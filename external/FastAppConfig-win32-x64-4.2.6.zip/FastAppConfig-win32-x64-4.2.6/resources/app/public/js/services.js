angular.module('DeployApp.services',[])
.factory('deployRequest', function() {
	function DeployRequest(){
		this.configId = 1;
		this.targetAppId = 0;
		this.deployDash = false;
		this.newDashName = "";
		this.deployHR = false;
		this.deployHRAndOverWrite=true;
	}
	
	function _deployRequest(){
		this.deployRequest = new DeployRequest();
	}
	
	return new _deployRequest();
})
.factory('deployTemplates', function($http,$location,$mdDialog) {
	
	function Templates(){
		this.data = null;
	}
	
	function _templatesService(){
		this.template = new Templates();
	}
	
	_templatesService.prototype.getTemplates = function($scope) {
		$http.get('/templates.json').success(function(result) {
			$scope.templates = result;
		});	
	}
	
	_templatesService.prototype.getApps = function($scope) {
		
		var allApp = {"description": "","id": 0,"name": "<All Applications>"};
		$http.get('/applications.json').success(function(result) {
			result.push(allApp);
			$scope.applications = result;
		});	
	}
	
	_templatesService.prototype.deployHealthRules = function($scope,template,application,overwrite) {
		
		$scope.showSpinner = true;
		var hrRequest = [];
		hrRequest.push(template);
		hrRequest.push(application);
		hrRequest.push(overwrite);
				
		$http({
		    url: '/copyhealthrules',
		    method: "POST",
		    data: JSON.stringify(hrRequest),
		    headers: {'Content-Type': 'application/json'}
		    }).success(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
		        $scope.showAlert(data);
		    }).error(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
		    });
	}
	
	_templatesService.prototype.deployDashboards = function(template,application,dashboardName) {
		
		var hrRequest = [];
		hrRequest.push(template);
		hrRequest.push(application);
		hrRequest.push(dashboardName);
				
		$http({
		    url: '/copydashboards',
		    method: "POST",
		    data: JSON.stringify(hrRequest),
		    headers: {'Content-Type': 'application/json'}
		    }).success(function (data, status, headers, config) {
		        $scope.showAlert(data);
		    }).error(function (data, status, headers, config) {
		    	
		    });
	}

	_templatesService.prototype.deployDynamicHR = function($scope) {

		$scope.showSpinner = true;
		var request = [];
		request.push($scope.sample.id);
		request.push($scope.selectedApp);
		request.push($scope.selectedTiers);
		request.push($scope.selectedBTs);

		$http({
		    url: '/deploySampleHealthRules/dynamic',
		    method: "POST",
		    data: JSON.stringify(request),
		    headers: {'Content-Type': 'application/json'}
		}).success(function (data, status, headers, config) {
			$scope.showSpinner = false;
		    $scope.showAlert(data);
		}).error(function (data, status, headers, config) {
			$scope.showSpinner = false;
		});
	}

	var deployMultipleHRs = function($scope,message,x){

		if( x < $scope.selectedApp.length ) {

			var selectedApp = $scope.selectedApp[x];
			$scope.showSpinner = true;
			var hrRequest = [];
			hrRequest.push($scope.sample.id);
			hrRequest.push(selectedApp.id);
				
			$http({
			    url: '/deploySampleHealthRules',
			    method: "POST",
			    data: JSON.stringify(hrRequest),
			    headers: {'Content-Type': 'application/json'}
		    }).success(function (data, status, headers, config) {
		    	deployMultipleHRs($scope,data,x+1);
		    }).error(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
				$scope.showAlert(data);
		    });
		}
		else
		{
			$scope.showSpinner = false;
			$scope.showAlert(message);
		}
	};

	_templatesService.prototype.deploySampleHR = function($scope) {

		if (Array.isArray($scope.selectedApp))
		{
			deployMultipleHRs($scope,"",0);
		}
		else
		{
			$scope.showSpinner = true;
			var hrRequest = [];
			hrRequest.push($scope.sample.id);
			hrRequest.push($scope.selectedApp.id);
				
			$http({
			    url: '/deploySampleHealthRules',
			    method: "POST",
			    data: JSON.stringify(hrRequest),
			    headers: {'Content-Type': 'application/json'}
		    }).success(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
		        $scope.showAlert(data);
		    }).error(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
		    });
		}
	}

	var deployMultipleDashboards = function($scope,message,x){

		if( x < $scope.selectedApp.length ) {

			var selectedApp = $scope.selectedApp[x];
			var request = [];
			request.push($scope.sample.id);
			request.push(selectedApp);
			request.push($scope.themeId);

			$http({
			    url: '/deploySampleDashboard',
			    method: "POST",
			    data: JSON.stringify(request),
			    headers: {'Content-Type': 'application/json'}
		    }).success(function (data, status, headers, config) {
				deployMultipleDashboards($scope,data,x+1);
			}).error(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
		    	$scope.showAlert(data);
			});
		}
		else
		{
			$scope.showSpinner = false;
			$scope.showAlert(message);
		}
	};

	_templatesService.prototype.deploySampleDashboard = function($scope) {

		$scope.showSpinner = true;
		
		if (Array.isArray($scope.selectedApp))
		{
			deployMultipleDashboards($scope,"",0);
		}
		else
		{
			var request = [];
			request.push($scope.sample.id);
			request.push($scope.selectedApp);
			request.push($scope.themeId);

			if ($scope.selectedBTs && $scope.selectedBTs.name)
			{
				request.push($scope.selectedBTs.name);
				request.push($scope.selectedBTs.tierName);
				request.push($scope.selectedBTs.entryPointType);
			}

			$http({
			    url: '/deploySampleDashboard',
			    method: "POST",
			    data: JSON.stringify(request),
			    headers: {'Content-Type': 'application/json'}
			}).success(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
		        $scope.showAlert(data);
			}).error(function (data, status, headers, config) {
		    	$scope.showSpinner = false;
			});
		}
	}

	_templatesService.prototype.deployDynamicDashboard = function($scope) {
		
		$scope.showSpinner = true;
		var request = [];
		request.push($scope.sample.id);
		request.push($scope.selectedApp);
		request.push($scope.themeId);
		request.push($scope.selectedTiers);
		request.push($scope.selectedBTs);
		request.push($scope.flows);
		
		$http({
		    url: '/deploySampleDashboard/dynamic',
		    method: "POST",
		    data: JSON.stringify(request),
		    headers: {'Content-Type': 'application/json'}
		}).success(function (data, status, headers, config) {
			$scope.showSpinner = false;
			$scope.showAlert(data);
		}).error(function (data, status, headers, config) {
			$scope.showSpinner = false;
		});
	}

	_templatesService.prototype.getHRList = function($scope,callback) {

		$scope.showSpinner = true;
		$http.get('/deploySampleDashboard/hrs/'+$scope.selectedApp.id).success(function(result) {	
	        $scope.showSpinner = false;
	        callback(result);
		});
	}

	_templatesService.prototype.getBTList = function($scope,callback) {
	
		$scope.showSpinner = true;

		$http.get('/deploySampleDashboard/bts/'+$scope.selectedApp.name).success(function(result) {	
	        $scope.showSpinner = false;
	        callback(result);
		});
	}

	_templatesService.prototype.getTierList = function($scope,callback) {
		$scope.showSpinner = true;
		$http.get('/tiers/'+$scope.selectedApp.id).success(function(result) {
			$scope.showSpinner = false;
	        callback(result);
		});	
	}

	return new _templatesService();
});
