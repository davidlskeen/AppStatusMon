angular.module('DeployApp.controllers', ['DeployApp.services', 'ngMaterial']).
controller('DeployController', function($scope,deployTemplates,$mdDialog,$element) {
    
	deployTemplates.getTemplates($scope);
	deployTemplates.getApps($scope);
	
	$scope.owHR = "true";	
	$scope.copy = "true";
	
	$scope.showSpinner = false;
	$scope.btList = [];
	$scope.tierList = [];
	$scope.selectedTiers;

	$scope.appSearchTerm;
	$scope.btSearchTerm;
	$scope.tierSearchTerm;
	$scope.selectAllTiers;
	$scope.selectAllTiersText;

	$scope.clearAppSearchTerm = function() {
		$scope.appSearchTerm = '';
	};
	$scope.clearBTSearchTerm = function() {
		$scope.btSearchTerm = '';
	};
	// The md-select directive eats keydown events for some quick select
	// logic. Since we have a search input here, we don't need that logic.
	$element.find('input').on('keydown', function(ev) {
		ev.stopPropagation();
	});

	$scope.init = function(value,selectedTheme) {
		$scope.sample = value;
		$scope.themeId = selectedTheme.id;
	};

  	$scope.applicationChanged = function(){
	    $scope.btList = [];
	    $scope.selectedBTs = [];
	    $scope.tierList = [];
	    $scope.selectedTiers = [];
	    $scope.hrList = [];

	    if ($scope.sample.loadHealthRules)
	    {
			deployTemplates.getHRList($scope, function(result) {	
		        $scope.hrList = result;
		        $scope.showSpinner = false;
			});
	    }

	    if($scope.sample.btSelection)
	    {
			deployTemplates.getBTList($scope, function(result) {	
		        $scope.btList = result;
		        $scope.showSpinner = false;
			});
	    }
	    if($scope.sample.tierSelection)
	    {
			deployTemplates.getTierList($scope, function(result) {	
		        $scope.tierList = result;
		        $scope.showSpinner = false;
		        $scope.selectAllTiers = true;
		        $scope.selectAllTiersText = "All";
				$scope.selectedTiers = [];
			});		    	
	    }
	};

	$scope.hasSelectedApp=function() {
		if (!$scope.selectedApp)
		{
			return false;
		}
		else if (Array.isArray($scope.selectedApp) && $scope.selectedApp.length == 0)
		{
			return false;
		} 
		else 
		{
			return true;
		}
	};

	$scope.pushHealthRules = function(template, application, overwrite) {
		deployTemplates.deployHealthRules($scope,template,application,overwrite);
	};
	
	$scope.selectBulkTiers = function(scope) {
		if ($scope.selectAllTiers)
		{
			$scope.selectAllTiersText = "None";
			$scope.selectedTiers = $scope.tierList;
		}
		else
		{
			$scope.selectAllTiersText = "All";
			$scope.selectedTiers = [];
		}
		$scope.selectAllTiers = !$scope.selectAllTiers;
	};

	$scope.getSelectedAppsText = function() {
		if (!$scope.selectedApp || $scope.selectedApp.length == 0) 
		{
			return "Applications";
		} 
		else if ($scope.selectedApp.length == 1)
		{
			return "1 Application Selected";
		}
		else 
		{
			return $scope.selectedApp.length + " Applications Selected";
		}
	};

	$scope.getSelectedTiersText = function() {
		if (!$scope.selectedTiers || $scope.selectedTiers.length == 0) 
		{
			return "Tiers";
		} 
		else if ($scope.selectedTiers.length == 1)
		{
			return "1 Tier Selected";
		}
		else 
		{
			return $scope.selectedTiers.length + " Tiers Selected";
		}
	};

	$scope.getSelectedBTsText = function() {
		if (!$scope.selectedBTs || $scope.selectedBTs.length == 0) 
		{
			return "Business Transactions";
		} 
		else if ($scope.selectedBTs.length == 1)
		{
			return "1 Business Transaction Selected";
		}
		else 
		{
			return $scope.selectedBTs.length + " Business Transactions Selected";
		}
	};

	$scope.pushDashboards = function(template, application, dashboardName) {
		deployTemplates.deployDashboards(template,application,dashboardName);
	};
	
	$scope.updateDashName = function(scope){
		scope.dashName = scope.selectedApp.name + ' - OPs';
	}
	
	$scope.deploySampleHR = function(scope){

		var canDeploy = $scope.canDeploy(scope);

		if (canDeploy.canDeploy)
		{
			if ($scope.sample.isDynamic)
			{
				deployTemplates.deployDynamicHR($scope);
			}
			else
			{
				deployTemplates.deploySampleHR($scope);
			}
		}
		else
		{
			$scope.showAlert(canDeploy.message)
		}
	}
	
	$scope.deploySampleDashboard = function(scope){

		var canDeploy = $scope.canDeploy(scope);

		if (canDeploy.canDeploy)
		{
			if ($scope.sample.isDynamic)
			{
				deployTemplates.deployDynamicDashboard($scope);
			}
			else
			{
				deployTemplates.deploySampleDashboard($scope);
			}
		}
		else
		{
			$scope.showAlert(canDeploy.message)
		}
	}

	$scope.canDeploy = function(scope){

		var returnValue = {};
		returnValue.canDeploy = true;

		if($scope.sample.tierSelection && (!$scope.selectedTiers || $scope.selectedTiers.length == 0))
		{
			returnValue.canDeploy = false;
			returnValue.message = "You must select at least one Tier to associate with this Dashboard.";
		}
		else if($scope.sample.tierSelection && $scope.sample.tierSelection > 1 && $scope.selectedTiers.length > $scope.sample.tierSelection)
		{
			returnValue.canDeploy = false;
			returnValue.message = "You can only choose " + $scope.sample.tierSelection + " Tiers for this Dashboard.";
		}
		else if($scope.sample.btSelection && (!$scope.selectedBTs || $scope.selectedBTs.length == 0))
		{
			returnValue.canDeploy = false;
			returnValue.message = "You must select a Business Transaction to associate with this Dashboard.";
		}
		else if($scope.sample.btSelection && $scope.sample.btSelection > 1 && $scope.selectedBTs.length > $scope.sample.btSelection)
		{
			returnValue.canDeploy = false;
			returnValue.message = "You can only choose " + $scope.sample.btSelection + " Business Transactions for this Dashboard.";
		}
		else if ($scope.sample.showWizard)
		{
			if ($scope.flows.length == 0) {

				returnValue.canDeploy = false;
				returnValue.message = "You must have at least one Flow.";
			}
			else {

				for (var i = 0; i < $scope.flows.length; i++) {
					var flow = $scope.flows[i];

					if (flow.steps.length == 0) {
						returnValue.canDeploy = false;
						returnValue.message = "Each Flow must have at least one Step.";
						break;
					}
					else {

						for (var j = 0; j < flow.steps.length; j++) {

							if (!flow.steps[j].hrName) {
								returnValue.canDeploy = false;
								returnValue.message = "Each Step must be linked to a Health Rule.";
								break;
							}
						}
					}
				}
			}
		}

		return returnValue;
	}

	$scope.showAlert = function(message) {
		$mdDialog.show(
			$mdDialog.alert()
			.parent(angular.element(document.querySelector('#popupContainer')))
			.clickOutsideToClose(true)
			.textContent(message)
			.ariaLabel('Alert Dialog Demo')
			.ok('OK')
		);
	};

	//
	// Wizard properties / functions
	//
	$scope.flows = [];
	$scope.selectedFlow = null;
	$scope.selectedStep = null;
	$scope.selectedFlowIndex = null;
	$scope.selectedStepIndex = null;
	$scope.selectedHRIndex = null;

	$scope.deleteFlow = function() {
		if ($scope.selectedFlowIndex != null) {
			$scope.flows.splice($scope.selectedFlowIndex, 1);
			$scope.selectFlow(null,null);
		}
	};
	$scope.deleteStep = function() {
		if ($scope.selectedFlowIndex != null && $scope.selectedStepIndex != null) {
			$scope.flows[$scope.selectedFlowIndex].steps.splice($scope.selectedStepIndex, 1);
			$scope.selectStep(null,null);
		}
	};

	$scope.addFlow = function() {
		var newFlow = {name:'Flow'+($scope.flows.length+1),steps:[{name:'Step1',hrName:null,hrIndex:null}]};
		$scope.flows.push(newFlow);
		$scope.selectFlow(newFlow,$scope.flows.length-1);
	};

	$scope.addStep = function(flow) {
		var newStep = {name:'Step'+(flow.steps.length+1),hrName:null,hrIndex:null};
		flow.steps.push(newStep);
		$scope.selectStep(newStep,flow.steps.length-1);
	};

	$scope.selectFlow = function(flow,index) {
		$scope.selectedFlow = flow;
		$scope.selectedFlowIndex = index;
		if (flow.steps.length > 0) {
			$scope.selectStep(flow.steps[0],0);
		}
		else {
			$scope.selectStep(null,null);
		}
	};
	
	$scope.selectStep = function(step,index) {
		$scope.selectedStep = step;
		$scope.selectedStepIndex = index;
		if (step) {
			$scope.selectedHRIndex = $scope.selectedStep.hrIndex;
		}
		else {
			$scope.selectedHRIndex = null;
		}
	};

	$scope.selectHR = function(index) {
		if ($scope.selectedHRIndex == index) {
			$scope.selectedHRIndex = null;
			$scope.selectedStep.hrIndex = null;
			$scope.selectedStep.hrName = null;
		}
		else {
			$scope.selectedHRIndex = index;
			$scope.selectedStep.hrIndex = index;
			$scope.selectedStep.hrName = $scope.hrList[index].name;
		}
	};	

	$scope.deployWizard = function(ev) {
		$mdDialog.show({
			templateUrl: 'dashboardWizard.html',
			locals: {parent: $scope},
			controller: angular.noop,
			controllerAs: 'ctrl',
			bindToController: true,
			targetEvent: ev,
			clickOutsideToClose:true,
			fullscreen: $scope.customFullscreen 
		});
	};

    $scope.hide = function() {
      $mdDialog.hide();
    };

    $scope.cancel = function() {
    	$scope.flows = [];
    	$scope.selectedFlow = undefined;
		$scope.selectedStep = undefined;
      	$mdDialog.cancel();
    };

});