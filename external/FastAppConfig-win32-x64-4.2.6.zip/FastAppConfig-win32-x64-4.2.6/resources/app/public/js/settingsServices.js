angular.module('SettingsApp.services',[])
.factory('settingsService', function($http) {
	
	function Settings(){
		this.data = null;
	}
	
	function _settingsService(){
		this.settings = new Settings();
	}
	
	_settingsService.prototype.getAllConfigItems = function($scope) {
		$http.get('/settings').success(function(result) {	
	        $scope.configJSON = result;
		});	
	}

	_settingsService.prototype.saveSettings = function($scope){
		
		$scope.showSpinner = true;
		var postData = [];
		postData.push($scope.configJSON);
				
		$http({
		    url: '/settings',
		    method: "POST",
		    data: postData,
		    headers: {'Content-Type': 'application/json'}
	    }).success(function (result) {
	    	$scope.showSpinner = false;
	    	$scope.configJSONSaved = $scope.configJSON;
			$scope.showAlert(result);
	    }).error(function(result) {
	    	$scope.showSpinner = false;
	    	$scope.showAlert(result);
	    });
	}	

	_settingsService.prototype.testConnection = function($scope){
		
		$scope.showSpinner = true;
		$http.get('/applications.json').success(function(result) {
			$scope.showSpinner = false;
			$scope.showAlert('Connection Test Successful');
		}).error(function(result) {
	    	$scope.showSpinner = false;
	    	$scope.showAlert('Connection Failed .. please verify username, password, account, controller, https/http, port. You can try setting restdebug:true in your configuration and checking restmanager.log');
	    });
	}

	return new _settingsService();
});
