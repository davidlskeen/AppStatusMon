angular.module('SampleApp.services',[])
.factory('sampleRequest', function() {
	function SampleRequest(){
		this.configId = 1;
		this.targetAppId = 0;
		this.deployDash = false;
		this.newDashName = "";
		this.deployHR = false;
		this.deployHRAndOverWrite=true;
	}
	
	function _sampleRequest(){
		this.sampleRequest = new SampleRequest();
	}

	_sampleRequest.prototype.getApps = function($scope) {
		$http.get('/applications.json').success(function(result) {
			$scope.applications = result;
		});	
	}
	
	return new _sampleRequest();
});
