angular.module('SettingsApp', ['SettingsApp.controllers','SettingsApp.services','ngMaterial']);

angular.module('SettingsApp.controllers', ['SettingsApp.services']).
directive('json', function() {
  return {
    restrict: 'A', // only activate on element attribute
    require: 'ngModel', // get a hold of NgModelController
    link: function(scope, element, attrs, ngModelCtrl) {
      function fromUser(text) {
        // Beware: trim() is not available in old browsers
        if (!text || text.trim() === '')
          return {}
        else
          return angular.fromJson(text);
      }

      function toUser(object) {
          return angular.toJson(object, true);
      }
      
      ngModelCtrl.$parsers.push(fromUser);
      ngModelCtrl.$formatters.push(toUser);
      
      scope.$watch(attrs.ngModel, function(newValue, oldValue) {
        if (newValue != oldValue) {
          ngModelCtrl.$setViewValue(toUser(newValue));
          ngModelCtrl.$render();
        }
      }, true); // MUST use objectEquality (true) here, for some reason..
    }
  };  
}).
controller('SettingsController', function($scope,$window,settingsService,$mdDialog,$element) {

	settingsService.getAllConfigItems($scope);
	$scope.showSpinner = false;
	$scope.configJSONSaved;

	$scope.saveSettings = function(scope){
		settingsService.saveSettings($scope);
	}	

  $scope.isDirty = function(scope) {
    if (!$scope.configJSONSaved || $scope.configJSONSaved != $scope.configJSON) {
      return true;
    }
    else {
      return false;
    }
  } 

	$scope.testConnection = function(scope){
		settingsService.testConnection($scope);
	}

	$scope.showAlert = function(message) {
		$mdDialog.show(
			$mdDialog.alert()
			.parent(angular.element(document.querySelector('#popupContainer')))
			.clickOutsideToClose(true)
			.textContent(message)
			.ariaLabel('Alert Dialog Demo')
			.ok('OK')
		);
	};			
});

